# traffic_sign > 2023-07-31 3:29pm
https://universe.roboflow.com/fpt-or9ue/traffic_sign-kihxq

Provided by a Roboflow user
License: CC BY 4.0

